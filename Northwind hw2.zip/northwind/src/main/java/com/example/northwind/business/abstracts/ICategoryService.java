package com.example.northwind.business.abstracts;

import java.util.List;
//import java.util.Map;
import java.util.Optional;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;

import com.example.northwind.entities.concretes.Category;

public interface ICategoryService { //FONKSİYONLARIN İMZALARI
	

	List<Category>getAll();

	Optional<Category> getById(Integer categoryId, Category category) throws Exception;
	
	Category add(@RequestBody Category category);
	
	ResponseEntity <Category> update
	(@PathVariable (value = "categoryId")Integer categoryId, @RequestBody Category category)throws Exception;

	//Map<String, Boolean> delete (@PathVariable (value = "categoryId") 
	//Integer categoryId, @RequestBody Category category) throws Exception;

	





}





