package com.example.northwind.api.controllers;

import java.util.List;
import java.util.Map;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.northwind.business.abstracts.IProductService;
import com.example.northwind.entities.concretes.Product;

@RestController
@RequestMapping("/api/v1")
public class ProductsController {

	@Autowired
	IProductService productService;
	
	@GetMapping("/products")
	public List<Product> getAll(){
		return productService.getAll();
	}
	
	@GetMapping("/products/{productId}")
	public Optional<Product> getById(Integer productId , Product product) throws Exception{
		return productService.getById(productId, product);
	}
		
	@PostMapping("/products")
	public Product add(@RequestBody Product product) {
		return productService.add(product);
	}
	
	@PutMapping("/products/{id}")
	public ResponseEntity <Product> update(Integer productId , Product product) throws Exception {
		return productService.update(productId, product);
	}
	
	@DeleteMapping("/products/{productId}")
	public Map<String, Boolean> delete (Integer productId , Product product) throws Exception{
		return productService.delete(productId, product);
		
	}
	

	
	
	
	
	
	
}	
	

