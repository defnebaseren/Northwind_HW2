package com.example.northwind.api.controllers;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.northwind.business.abstracts.ICategoryService;
import com.example.northwind.entities.concretes.Category;

@RestController
@RequestMapping("/api/v1")
public class CategoryController {

	@Autowired
	ICategoryService categoryService;
	

	@GetMapping("/categories")
	public List<Category> getAll(){
		return categoryService.getAll();
	}
	
	@GetMapping("/categories/{categoryId}")
	public Optional<Category> getById(@PathVariable (value = "categoryId")Integer categoryId, @RequestBody Category category) throws Exception{
		return categoryService.getById(categoryId, category);
		}
	
	@PostMapping("/categories")
	public Category add(@RequestBody Category category) {
		return categoryService.add(category);
	}
	
	@PutMapping("/categories/{categoryId}")
	public ResponseEntity<Category> update(Integer categoryId, @RequestBody Category category) throws Exception{
		return categoryService.update(categoryId, category);
		
	}
	
	//@DeleteMapping("/categories/{categoryId}")
		//public Map<String, Boolean> delete((@PathVariable (value = "categoryId") Integer categoryId, @RequestBody Category category) throws Exception {
		//return categoryService.delete(categoryId, category);
	//}
	
}
	
	
	
	
	

