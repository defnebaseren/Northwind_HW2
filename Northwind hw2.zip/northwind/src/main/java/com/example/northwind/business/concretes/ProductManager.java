package com.example.northwind.business.concretes;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;

import com.example.northwind.business.abstracts.IProductService;
import com.example.northwind.dataaccess.concretes.ProductRepository;
import com.example.northwind.entities.concretes.Product;

@Service
public class ProductManager implements IProductService{

	@Autowired
	ProductRepository productRepository;
	

	@Override
	@GetMapping("/products")
	public List<Product> getAll() {
		return productRepository.findAll();
	}
	

	
	@Override
	@GetMapping("/products/{productId}")
	public Optional<Product> getById
		(@PathVariable (value = "productId")Integer productId, @RequestBody Product product)throws Exception{
		product = productRepository.findById(productId).orElseThrow(()->new Exception("No product with ID: " + productId));
		return productRepository.findById(productId);
	
	}
	
	@Override
	@PostMapping("/products")
	public Product add(@RequestBody Product product) {
		if  (product.getProductName().length()<2){
			System.out.println("Product name has to be longer than 2 characters");
		}
		else {
			return productRepository.save(product);	
		}
		return product;


	}

	@Override
	@PutMapping("/products/{id}")
	public ResponseEntity <Product> update
	(@PathVariable (value = "productId")Integer productId, @RequestBody Product product)throws Exception{
		Product productToUpdate = productRepository.findById(productId).orElseThrow(()->new Exception("No product with ID: " + productId));
		productToUpdate.setProductName(product.getProductName());
		productToUpdate.setUnitPrice(product.getUnitPrice());
		Product updatedProduct = productRepository.save(productToUpdate);
		return ResponseEntity.ok(updatedProduct);
	}
	

	
	@Override
	@DeleteMapping("/products/{productId}")
	public Map<String, Boolean> delete (@PathVariable (value = "productId") 
	Integer productId, @RequestBody Product product) throws Exception{
	Product productToBeDeleted= productRepository.findById(productId).orElseThrow(()->new Exception("No customer with ID: " + productId));
		
		productRepository.delete(productToBeDeleted);
		Map<String, Boolean> response = new HashMap<>();
		response.put("deleted", Boolean.TRUE);
		return response;
	}


}


