package com.example.northwind.business.abstracts;

import java.util.List;
import java.util.Map;
import java.util.Optional;

import org.springframework.http.ResponseEntity;
//import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;

import com.example.northwind.entities.concretes.Product;


public interface IProductService{  //FONKSİYON İMZALARI 
	
	
	List<Product>getAll();
		
	Product add(@RequestBody Product product);
	
	//Optional<Product> getById
	//(@PathVariable (value = "productId")Product productId, @RequestBody Product product)throws Exception;
	
	ResponseEntity<Product> update(Integer productId, Product product) throws Exception;

	Optional<Product> getById(Integer productId, Product product) throws Exception;

	Map<String, Boolean> delete(Integer productId, Product product) throws Exception;



}
