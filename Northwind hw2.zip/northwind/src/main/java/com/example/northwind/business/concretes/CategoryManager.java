package com.example.northwind.business.concretes;


//import java.util.HashMap;
import java.util.List;
//import java.util.Map;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
//import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
//import Category org.springframework.data.repository.CrudRepository.save(Category entity)


import com.example.northwind.business.abstracts.ICategoryService;
import com.example.northwind.dataaccess.concretes.CategoryRepository;
import com.example.northwind.entities.concretes.Category;

@Service
public class CategoryManager implements ICategoryService{

	@Autowired
	CategoryRepository categoryRepository;

	
	@Override
	@GetMapping("/categories")
	public List<Category>getAll(){
		return categoryRepository.findAll();
	
	}
	
	@Override
	@GetMapping("/categories/{categoryId}")
	public Optional<Category> getById(@PathVariable (value = "categoryId")Integer categoryId, @RequestBody Category category)
		throws Exception{
		
		category = categoryRepository.findById(categoryId).orElseThrow(()->new Exception("No category with ID: " + categoryId));{
		return categoryRepository.findById(categoryId);
		}
	}

	@Override
	@PostMapping("/categories")
	public Category add(@RequestBody Category category) {
		System.out.println(category.getCategoryName());
		return categoryRepository.save(category);
	}

	@Override
	@PutMapping("/categories/{categoryId}")
	public ResponseEntity<Category> update(Integer categoryId, @RequestBody Category category) throws Exception {
		Category categoryToUpdate = categoryRepository.findById(categoryId).orElseThrow(()->new Exception("No category with ID: " + categoryId));
		categoryToUpdate.setCategoryName(category.getCategoryName());
		Category updatedCategory = categoryRepository.save(categoryToUpdate);
		return ResponseEntity.ok(updatedCategory);
	}
	

	


	//@Override
	//@DeleteMapping("/categories/{categoryId}")
	//public Map<String, Boolean> delete((@PathVariable (value = "categoryId") Integer categoryId, @RequestBody Category category) throws Exception {
		//Category categoryToBeDeleted= categoryRepository.findById(categoryId).orElseThrow(()->new Exception("No category with ID: " + categoryId));
		//categoryRepository.delete(categoryToBeDeleted);
		//Map<String, Boolean> response = new HashMap<>();
		//response.put("deleted", Boolean.TRUE);
		//return response;
	//}





	
}